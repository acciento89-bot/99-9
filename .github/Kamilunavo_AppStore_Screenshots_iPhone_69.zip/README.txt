Kamilunavo – App Store Screenshots
Erstellt aus den gelieferten TestFlight-Screenshots.

Zielgröße iPhone 6.9":
1320 x 2868 px, Hochformat

Zuordnung / Reihenfolge:
VolumeCalc: Übersicht
AnlagenCheck: Prüfen, Checkliste, Bericht
HeizkörperCalc: Leistung, Raum auslegen, Temperaturen
RohrCalc: Hydraulik, Dimension, Matrix
LüftungsCalc: Kanal, Raum, Umrechner
KälteCalc: Kältekreis, Luftseite, Tools
